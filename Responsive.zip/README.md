# Responsive media query
This is a responsive media query.
Technology used:HTML AND CSS# Zuri-responsiveness-and-media-query
# Zuri-responsiveness-and-media-query
